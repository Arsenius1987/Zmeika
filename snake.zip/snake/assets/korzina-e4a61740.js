import"./style-e5ec309f.js";const a=localStorage.korzina?JSON.parse(localStorage.korzina):[];let t=0;a.forEach(n=>{document.body.insertAdjacentHTML("beforeend",e(n)),t+=n.price*n.count});document.body.insertAdjacentHTML("beforeend",`
  <p>Итого ${t}$ <button>Оплатить</button></p> 
`);function e(n){return`
  <div style="display:flex; margin:0 auto; max-width: 700px; padding: 20px; gap: 20px">
    <img style="min-width:200px" href="${n.image}">
    <div>
      <h4>${n.name}</h4>  
      <p>${n.description}</p>
      <p style="display:flex; justify-content: space-between;">
        <span>${n.price}</span>
        <span>${n.count}</span>
        <span>${n.price*n.count}$</span>
      </p>
    </div>
  </div>
  `}
